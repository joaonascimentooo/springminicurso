package com.tarefa.api.minicurso.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

// Anotação Lombok para geração automática de getters, setters, equals, hashCode, e toString
@Data
@Entity(name = "tb_tarefas")  // Indica que essa classe é uma entidade JPA mapeada para a tabela 'tb_tarefas'
public class TarefaModel {

    @Id  // Indica que 'id' é a chave primária da entidade
    @GeneratedValue(strategy = GenerationType.AUTO)  // Gera automaticamente valores para 'id' usando uma estratégia padrão
    private Integer id;

    private String nome;  // Atributo para armazenar o nome da tarefa

    // Construtor padrão necessário para entidades JPA
    public TarefaModel() {
    }

    // Construtor que permite criar uma nova tarefa com um nome específico
    public TarefaModel(String nome) {
        this.nome = nome;
    }

    // Método para atualizar os campos da tarefa com base em uma tarefa atualizada
    public void atualizar(TarefaModel tarefaAtualizada) {
        // Verifica se o nome da tarefa atualizada não é nulo e o atualiza se necessário
        if (tarefaAtualizada.getNome() != null) {
            this.nome = tarefaAtualizada.getNome();
        }
    }

    // Método para obter o ID da tarefa
    public Integer getId() {
        return id;
    }
}
