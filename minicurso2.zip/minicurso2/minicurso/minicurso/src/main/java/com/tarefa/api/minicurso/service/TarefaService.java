package com.tarefa.api.minicurso.service;

import com.tarefa.api.minicurso.model.TarefaModel;
import com.tarefa.api.minicurso.repository.TarefaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TarefaService {

    @Autowired  // Injeção de dependência do repositório TarefaRepository
    private TarefaRepository tarefaRepository;

    // Método para listar todas as tarefas no banco de dados
    public List<TarefaModel> listar() {
        return tarefaRepository.findAll();
    }

    // Método para salvar uma nova tarefa no banco de dados
    public TarefaModel salvar(TarefaModel tarefa) {
        return tarefaRepository.save(tarefa);
    }

    // Método para atualizar uma tarefa existente no banco de dados
    public TarefaModel atualizar(Integer id, TarefaModel tarefaAtualizada) {
        // Procura a tarefa pelo ID no banco de dados
        Optional<TarefaModel> tarefaExistente = tarefaRepository.findById(id);

        // Verifica se a tarefa existe
        if (tarefaExistente.isPresent()) {
            TarefaModel tarefa = tarefaExistente.get();

            // Chama o método 'atualizar' da tarefa para modificar os campos necessários
            tarefa.atualizar(tarefaAtualizada);

            // Salva a tarefa atualizada no banco de dados
            return tarefaRepository.save(tarefa);
        } else {
            // Retorna nulo se a tarefa não existir
            return null;
        }
    }

    // Método para excluir uma tarefa pelo ID
    public void excluir(Integer id) {
        tarefaRepository.deleteById(id);
    }
}
