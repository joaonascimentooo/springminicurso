package com.tarefa.api.minicurso.controller;

import com.tarefa.api.minicurso.model.TarefaModel;
import com.tarefa.api.minicurso.service.TarefaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tarefas")
public class TarefaController {

    // Injeção de dependência do serviço TarefaService
    @Autowired
    private TarefaService tarefaService;

    // Endpoint para a operação de consulta (GET) que retorna a lista de tarefas
    @GetMapping
    public List<TarefaModel> listar() {
        return tarefaService.listar();
    }

    // Endpoint para a operação de criação (POST) que cadastra uma nova tarefa
    @PostMapping
    public TarefaModel cadastrar(@RequestBody TarefaModel tarefa) {
        return tarefaService.salvar(tarefa);
    }

    // Endpoint para a operação de atualização (PUT) que atualiza uma tarefa existente
    // O ID da tarefa a ser atualizada é passado como parte da URL
    @PutMapping("/{id}")
    public TarefaModel atualizar(@PathVariable Integer id, @RequestBody TarefaModel tarefa) {
        // Verifica se o ID na URL é o mesmo que o ID na tarefa recebida no corpo da requisição
        if (!id.equals(tarefa.getId())) {
            // Retorna nulo se os IDs não coincidirem
            return null;
        }

        // Chama o serviço para realizar a atualização da tarefa
        return tarefaService.atualizar(id, tarefa);
    }

    // Endpoint para a operação de exclusão (DELETE) que remove uma tarefa pelo ID
    @DeleteMapping("/{id}")
    public void excluir(@PathVariable Integer id) {
        System.out.println("Deletado com sucesso");// Chama o serviço para realizar a exclusão da tarefa pelo ID
        tarefaService.excluir(id);
    }
}
