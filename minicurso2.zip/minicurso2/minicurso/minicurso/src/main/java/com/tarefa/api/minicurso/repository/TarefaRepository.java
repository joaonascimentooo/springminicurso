package com.tarefa.api.minicurso.repository;

import com.tarefa.api.minicurso.model.TarefaModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TarefaRepository extends JpaRepository<TarefaModel, Integer> {
}