package com.tarefa.api.minicurso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinicursoApplicationTests {

	@Test
	void contextLoads() {
	}

}
